function gravityForce = GetGravityForce(alpha, m, g)
gravityForce = m*g*sind(alpha);
end

