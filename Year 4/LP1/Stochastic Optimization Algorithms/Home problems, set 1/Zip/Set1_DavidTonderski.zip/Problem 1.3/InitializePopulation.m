function population = InitializePopulation(populationSize,nGenes)

population = randi([0,1],populationSize, nGenes);

end

