function value = cost(phasetrans, data, start)
%COST Summary of this function goes here
%   Detailed explanation goes here
peo1 = data(start:phasetrans,1);
peominusal2o31 = data(start:phasetrans, 2);

peo2 = data(phasetrans:end,1);
peominusal2o32 = data(phasetrans:end, 2);

[p, S] = polyfit(peo1, peominusal2o31, 1);
cost = getfield(S,"normr");

[p, S] = polyfit(peo2, peominusal2o32, 1);
cost = cost + getfield(S, "normr");

value = cost;
end

