clear,clc,clf

data = xlsread('Avjoniserat vatten.xlsm');
weight = data(:,1)-0.2;
plot([1:518],weight(1:518), 'b');

hold on

data = xlsread('100gsalt.xlsx');
weight = data(:,1);
plot([1:518],weight(1:518), 'g');
 
data = xlsread('50gsalt.xlsx');
weight = data(:,1);
plot([1:518],weight(1:518), 'r');


data = xlsread('Natriumacetat100g.xlsx');
weight = data(:,1);
plot([1:518],weight(1:518), 'black');


data = xlsread('NatriumacetatUtanvatten100g.xlsx');
weight = data(:,1);
plot([1:518],weight(1:518), 'y');

