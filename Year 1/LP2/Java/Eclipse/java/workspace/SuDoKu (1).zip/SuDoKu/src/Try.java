import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class Try extends JFrame{
	private JButton f = new JButton("JP2");
	private JPanel k = new JPanel();
	private JSplitPane p = new JSplitPane(JSplitPane.VERTICAL_SPLIT,f,k);
	private JButton m = new JButton("JP3");
	private JButton n = new JButton("JPn");

	public Try(){
		k.setLayout(new GridLayout(1,2));
		add(p);
		k.add(m);
		k.add(n);
		setSize(500,500);
		setVisible(true);
		
	}
	public static void main(String[] args){
		Try t = new Try();
		
	}

}
