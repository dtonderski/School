import java.awt.*;
import java.beans.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class MySudokuView extends JPanel implements PropertyChangeListener{
	protected SudokuModel model;
	private JPanel board = new JPanel();
	JPanel[][] boxes = new JPanel[3][3];
	JTextField[][] squares = new JTextField[9][9];
	
	
	public void propertyChange(PropertyChangeEvent e){

		this.repaintAll();
	}
	
	public void repaintSquare(int rad,int kol){
		squares[rad][kol].setText(Integer.toString(model.getBoard(rad,kol)));
		squares[rad][kol].setEnabled(false);
		squares[rad][kol].setDisabledTextColor(Color.black);
		squares[rad][kol].setBackground(Color.lightGray);
	}
	
	public void repaintAll(){
		for(int rad=0;rad<9;rad++){
			for(int kol=0;kol<9;kol++){
				if(model.getBoard(rad,kol)!=0){
					squares[rad][kol].setText(Integer.toString(model.getBoard(rad,kol)));
					squares[rad][kol].setEnabled(false);
					squares[rad][kol].setDisabledTextColor(Color.black);
					squares[rad][kol].setBackground(Color.lightGray);
				}
			}
		}
		revalidate();
		repaint();
	}
	@Override
	public Dimension getPreferredSize(){
		return new Dimension(500,500);
	}
	public MySudokuView(SudokuModel m, SudokuController c){
		setBackground(Color.white);
	    board = new JPanel(new GridLayout(3, 3));
		if(model!=null){
			model.removePropertyChangeListener(this);
		}
		this.model = m;
		model.addPropertyChangeListener(this);
		for(int rad=0;rad<3;rad++){
			for(int kol=0;kol<3;kol++){
				boxes[rad][kol]= new JPanel();
				board.add(boxes[rad][kol]);
				boxes[rad][kol].setLayout(new GridLayout(3,3));
				boxes[rad][kol].setBorder(new LineBorder(Color.black, 1));	
				}
		}
		int blockKolumn;
		int blockRad;
		for(int rad=0;rad<9;rad++){
			for(int kol=0;kol<9;kol++){
				blockKolumn= (kol-kol%3)/3;
				blockRad=(rad-rad%3)/3;
				squares[rad][kol]= new JTextField();
				boxes[blockRad][blockKolumn].add(squares[rad][kol]);
				squares[rad][kol].setHorizontalAlignment(SwingConstants.CENTER);
				squares[rad][kol].setMinimumSize(new Dimension(10,10));
				if(model.getBoard(rad,kol)!=0){
					squares[rad][kol].setText(Integer.toString(model.getBoard(rad,kol)));
					squares[rad][kol].setEnabled(false);
					squares[rad][kol].setDisabledTextColor(Color.black);
					squares[rad][kol].setBackground(Color.lightGray);
				}
			}
		}
		setSize(500,500);
		add(board);
		setVisible(true);
	}

	public static void main (String[] args){
		MySudokuModel modell = new MySudokuModel();
		//MySudokuView c = new MySudokuView(modell);
		modell.setBoard("000000907\n000420180\n000705026\n100904000\n050000040\n000507009\n920108000\n034059000\n507000000");
	}
}

