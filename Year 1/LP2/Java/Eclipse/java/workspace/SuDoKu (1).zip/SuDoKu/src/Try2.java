import java.awt.*;
import java.beans.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class Try2 extends JFrame{
	private SudokuModel model;
	
	public Try2(){
		model = new MySudokuModel();
		model.setBoard("534678012\n672190348\n198340567\n859761423\n426853791\n713924856\n961537284\n287419635\n345286179");
		MySudokuView k = new MySudokuView(model);
		add(k);
		setVisible(true);
	}
	public static void main(String[] args){
		Try2 x = new Try2();
	}

}
