import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;


public class Something extends JFrame {
	private JPanel menu= new JPanel();
	private JPanel board = new JPanel();
	private JButton k1 = new JButton("Clear Board");
	private JButton k2 = new JButton("Check If Solvable");
	private JButton k3 = new JButton("Solve Current Board");
	private JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,board,menu);
	JPanel[][] boxes = new JPanel[3][3];
	JTextField[][] squares = new JTextField[9][9];

	public Something(){
		super("SudokuMeister");
		for(int rad=0;rad<3;rad++){
			for(int kol=0;kol<3;kol++){
				boxes[rad][kol]= new JPanel();
				board.add(boxes[rad][kol]);
				boxes[rad][kol].setLayout(new GridLayout(3,3));
				boxes[rad][kol].setBorder(new LineBorder(Color.black, 1));	
				}
		}
		int blockKolumn;
		int blockRad;
		for(int rad=0;rad<9;rad++){
			for(int kol=0;kol<9;kol++){
				blockKolumn= (kol-kol%3)/3;
				blockRad=(rad-rad%3)/3;
				squares[rad][kol]= new JTextField();
				boxes[blockRad][blockKolumn].add(squares[rad][kol]);
			}
		}
		add(split);
		board.setLayout(new GridLayout(3,3));
		menu.setLayout(new FlowLayout());
		menu.setSize(300,200);
		menu.setBackground(Color.white);
		menu.add(k1);
		menu.add(k2);
		menu.add(k3);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(350,250);
	}
	public static void main (String[] args){
		Something t = new Something();
	}
}
