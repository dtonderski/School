import java.beans.*;
import java.util.*;

public class MySudokuModel implements SudokuModel{
		
	private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
	
	public void addPropertyChangeListener(PropertyChangeListener l){
		pcs.addPropertyChangeListener(l);
	}
		
	public void removePropertyChangeListener(PropertyChangeListener l){
		pcs.removePropertyChangeListener(l);
	}
	

	private int[][] m = new int[9][9];
		
	public MySudokuModel(){
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=0;
			}
		}	
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public int getBoard(int rad, int kolumn){
		return m[rad][kolumn];
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	
	public String getBoard(){
		String HelaSpelet = "";
		for(int i=0; i<9; i++){
			for(int p=0; p<9; p++){
				HelaSpelet=HelaSpelet + Integer.toString(m[i][p]);
				}
			HelaSpelet = HelaSpelet + "\n";
			}
		return HelaSpelet;
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	@Override
	public String toString(){
		return getBoard();
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public int getNextSmallest(){

		return 2;
		
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public boolean isUnique(){
		if(this.solve()){
			if(this.solve(0)){
				return false;
			}
			else{
				return true;
			}
		}
		else{
			return false;
		}
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public boolean solve(int i){
		//om AntalNollor=0 return true
		int AntalNollor = 0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					AntalNollor++;
				}
			}
		}
		if(AntalNollor==0&& i ==0){
			i++;
		}
		
		if(AntalNollor==0&& i !=0){
			return true;
		}
		
		//hittar vilken cell som har minst antal nollor i block kolumn o rad
		int blockNollor[][]= new int[3][3];
		for(int blockRad=0;blockRad<3;blockRad++){
			for(int blockKolumn=0;blockKolumn<3;blockKolumn++){
				for(int rad=blockRad*3; rad<blockRad*3+3; rad++){
					for(int kol=blockKolumn*3; kol<blockKolumn*3+3;kol++){
						if(m[rad][kol]==0){
							blockNollor[blockRad][blockKolumn]++;
						}
					}
				}
			}
		}
		int nollorIRad[]= new int[9];
		int nollorIKol[] = new int[9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					nollorIRad[r]++;
					nollorIKol[k]++;
				}
			}
		}
		int blockKolumn=0;
		int blockRad=0;
		int nollor[][] = new int[9][9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					blockKolumn= (k-k%3)/3;
					blockRad=(r-r%3)/3;
					nollor[r][k]=nollorIRad[r]+nollorIKol[k]+blockNollor[blockRad][blockKolumn];
				
				}
			}
		}
		int kolNolMin=0;
		int radNolMin=0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
					break;
				}
			}
		}
		
		for(int r=0;r<9;r++){
			for(int k=0; k<9;k++){
				if(nollor[r][k]<nollor[radNolMin][kolNolMin]&&m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
				}
			}
		}
		//löser sudokut genom rekursion
		for(int number=1;number<=9;number++){
			if(isLegal(radNolMin, kolNolMin, number)){
				m[radNolMin][kolNolMin] = number;
				if(solve()){
					return true;
				}
				else{
					m[radNolMin][kolNolMin] = 0;
				}
			}
		}
		return false;
		
	}
	List <MySudokuModel> lista = new ArrayList<>();
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public boolean solve(){
		lista.add(this);
		//om AntalNollor=0 return true
		int AntalNollor = 0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					AntalNollor++;
				}
			}
		}
		if(AntalNollor==0){
			pcs.firePropertyChange("Modell",lista.get(0), this);
			lista.clear();
			return true;
		}
		//hittar vilken cell som har minst antal nollor i block kolumn o rad
		int blockNollor[][]= new int[3][3];
		for(int blockRad=0;blockRad<3;blockRad++){
			for(int blockKolumn=0;blockKolumn<3;blockKolumn++){
				for(int rad=blockRad*3; rad<blockRad*3+3; rad++){
					for(int kol=blockKolumn*3; kol<blockKolumn*3+3;kol++){
						if(m[rad][kol]==0){
							blockNollor[blockRad][blockKolumn]++;
						}
					}
				}
			}
		}
		int nollorIRad[]= new int[9];
		int nollorIKol[] = new int[9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					nollorIRad[r]++;
					nollorIKol[k]++;
				}
			}
		}
		int blockKolumn=0;
		int blockRad=0;
		int nollor[][] = new int[9][9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					blockKolumn= (k-k%3)/3;
					blockRad=(r-r%3)/3;
					nollor[r][k]=nollorIRad[r]+nollorIKol[k]+blockNollor[blockRad][blockKolumn];
				
				}
			}
		}
		int kolNolMin=0;
		int radNolMin=0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
					break;
				}
			}
		}
		
		for(int r=0;r<9;r++){
			for(int k=0; k<9;k++){
				if(nollor[r][k]<nollor[radNolMin][kolNolMin]&&m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
				}
			}
		}
		//löser sudokut genom rekursion
		for(int number=1;number<=9;number++){
			if(isLegal(radNolMin, kolNolMin, number)){
				m[radNolMin][kolNolMin] = number;
				if(solve()){
					return true;
				}
				else{
					m[radNolMin][kolNolMin] = 0;
				}
			}
		}
		lista.clear();
		return false;
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public boolean isSolvable(){
		MySudokuModel kopia = new MySudokuModel(this);
		return kopia.solve();
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	public MySudokuModel(MySudokuModel f){
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=f.getBoard(r,k);
			}
		}	
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void clear(){
		MySudokuModel oldModel = this;
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=0;
			}
		}	
		MySudokuModel newModel=this;
		pcs.firePropertyChange("Modell", oldModel, newModel);
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void setBoard(int rad, int kolumn, int value){
		int oldValue = m[rad][kolumn];
		if(isLegal(value, rad, kolumn)==false){
			throw new IllegalArgumentException("Olagligt värde!");
		}
		else{
			m[rad][kolumn]=value;
			int newValue=m[rad][kolumn];
			pcs.fireIndexedPropertyChange("Value", 9*rad+kolumn, oldValue, newValue);
		}
		

	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	//Metod som kollar om man får sätta in värdet value i den angivna raden och kolumnen
	public boolean isLegal(int rad, int kolumn, int value){
		for(int i=0;i<9;i++){
			//kör igenom alla värden för den angivna raden och kollar om något är samma som värdet value, om det inte är på samma plats så returneras false
			if(m[rad][i]==value && i!=kolumn){
				return false;
			}
			//kör igenom alla värden för den angivna kolumnen och kollar om något är samma som värdet value, om det inte är på samma plats så returneras false
			if(m[i][kolumn]==value && i!=rad){
				return false;
			}
		}
		//blocken numreras på följande sätt:
		//(0,0) (0,1) (0,2)
		//(1,0) (1,1) (1,2)
		//(2,0) (2,1) (2,2)
		//rad2 är den första "koordinaten", kol2 är den andra "koordinaten"
		//rad2 är alltså antalet gånger som tre går in i rad
		//kol2 är antalet gånger som tre går in i kolumn
		int rad2=((rad)-(rad)%3)/3;
		int kol2=(kolumn-kolumn%3)/3;
		//värdena som behöver kollas är alltså de vars rad är från rad2*3 till rad2*3 +3 och de vars kolumn är från kolumn2*3 till kolumn2*3 + 3
		for(int r=(0+rad2*3);r<(3+rad2*3);r++){
			for(int k = (0+kol2*3); k<(3+kol2*3); k++){
				if(m[r][k]==value && r!=rad && k!=kolumn){
					return false;
				}
			}
		}
		return true;
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void setBoard(String s) throws IllegalArgumentException{
		MySudokuModel oldModel= this;
		int rn;
		int kn;
		if(s==null || s.isEmpty()){
			throw new IllegalArgumentException("Stringen är tom!");
		}
		String rader[] = s.split("\\n");
		
		if(rader.length!=9){
			throw new IllegalArgumentException("Fel format!");
		}
		
		for(int i=0;i<9;i++){
			if(rader[i].length()!=9){
				throw new IllegalArgumentException("Fel format!");
			}
		}
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				char character = rader[r].charAt(k);
				String tecken = Character.toString(character);
				if(tecken.matches("[0-9]+")){
					int value=Integer.parseInt(tecken);
					if(isLegal(r,k,value)==false){
						rn=r+1;
						kn=k+1;
						System.out.println("Olagligt tecken i rad " + rn + " och kolumn " + kn + "!");
					}
					else{
						m[r][k]=value;
					}
				}
				else{
					m[r][k]=0;
				}
			}	
		}
		MySudokuModel newModel=this;
		pcs.firePropertyChange("Modell", oldModel, newModel);
		
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	

	
	public static void main(String[] args){
		MySudokuModel k = new MySudokuModel();
		k.clear();
		k.setBoard("534678012\n672190348\n198340567\n859761423\n426853791\n713924856\n961537284\n287419635\n345286179");

		MySudokuModel f = new MySudokuModel();
		f.setBoard("000000907\n000420180\n000705026\n100904000\n050000040\n000507009\n920108000\n034059000\n507000000");
		System.out.println(f.solve());
		System.out.println(f.getBoard());
		
		MySudokuModel omojligt = new MySudokuModel();
		omojligt.setBoard("781543926\n006179500\n954628731\n695837214\n148265379\n327914800\n413752698\n002000400\n579486103");
		System.out.println(omojligt.solve());
		System.out.println(omojligt.getBoard());
	

		

	}
}
