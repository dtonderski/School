package controller;

public class Move {
	private int oldValue;
	private int newValue;
	private int rad;
	private int col;
	public Move(int old, int New, int r, int c){
		oldValue=old;
		newValue=New;
		rad=r;
		col=c;
		
	}
	
	public int getOldValue(){
		return oldValue;
	}
	
	public int getRad(){
		return rad;
	}
	
	public int getColumn(){
		return col;
	}
	
	public int getNewValue(){
		return newValue;
	}
}
