package view;
import java.awt.*;
import java.beans.*;
import java.io.Console;
import java.util.concurrent.TimeUnit;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import controller.SudokuController;
import model.MySudokuModel;
import model.SudokuModel;


public class MySudokuView extends JPanel implements PropertyChangeListener{
	
	//lägger till variabeln model
	protected SudokuModel model;
	
	//initialiserar brädet
	private JPanel board = new JPanel();
	//initialiserar de 9 blocken
	JPanel[][] boxes = new JPanel[3][3];
	//initialiserar rutorna
	squares[][] squares = new squares[9][9];
	//färg till bakgrunden när rutan är inaktiv
	private Color disabledBackgroundColour = new Color((float) 0.93,(float) 0.93,(float) 0.93);
	//Default border
	JTextField border = new JTextField("2");
	private Border DefaultBorder = border.getBorder();
	

	public void propertyChange(PropertyChangeEvent e){
		//om e inte är IndexedPropertyChangeEvent så körs metoden repaintAll
		if(!(e instanceof IndexedPropertyChangeEvent)){
			repaintAll();
		}
		//annars görs e om till en IndexedPropertyChangeEvent och repaintSquare körs på den ändrade rutan
		if(e instanceof IndexedPropertyChangeEvent){
			IndexedPropertyChangeEvent ev = (IndexedPropertyChangeEvent) e;
			repaintSquare(ev.getIndex()/9, ev.getIndex()%9);
		}
	}
	
	//ritar om en ruta genom att få in dess värde från modellen
	public void repaintSquare(int rad,int kol){
		//om rutan är blank blir den blank, vit och enabled
		if(model.getBoard(rad,kol)==0){
			squares[rad][kol].setText("");
			squares[rad][kol].setEnabled(true);
			squares[rad][kol].setBackground(Color.white);
		}
		//annars är den ifylld, så den fylls i med rätt värde, blir grå och disabled
		else{
			squares[rad][kol].setText(Integer.toString(model.getBoard(rad,kol)));
			squares[rad][kol].setEnabled(false);
			squares[rad][kol].setBackground(disabledBackgroundColour);
		}

	}
	
	//kör repaintSquare på alla rutor
	public void repaintAll(){
		for(int rad=0;rad<9;rad++){
			for(int kol=0;kol<9;kol++){ 
				repaintSquare(rad,kol);
			}
		}

	}

	
	//konstruktor för MySudokuView
	public MySudokuView(SudokuModel m, SudokuController c){
		//sätter bakgrunden till vitt
		setBackground(Color.white);
		//sätter JPaneln board till en JPanel med 3x3 GridLayout
	    board = new JPanel(new GridLayout(3, 3));
	    //tar bort lyssnare från eventuell gammal modell
		if(model!=null){
			model.removePropertyChangeListener(this);
		}
		//sätter variabeln model till parametern m
		this.model = m;
		//lägger till lyssnare till den nya modellen
		model.addPropertyChangeListener(this);
		
		//initialiserar blocken, lägger till dem i board, sätter deras storlek, sätter de till en 3x3 GridLayout (för att sedan kunna sätta in rutor i dem), sätter border till svart, och gör dem synliga
		for(int rad=0;rad<3;rad++){
			for(int kol=0;kol<3;kol++){
				boxes[rad][kol]= new JPanel();
				board.add(boxes[rad][kol]);
				boxes[rad][kol].setPreferredSize(new Dimension(100,100));
				boxes[rad][kol].setLayout(new GridLayout(3,3));
				boxes[rad][kol].setBorder(new LineBorder(Color.black, 1));	
				boxes[rad][kol].setVisible(true);
				}
		}
		
		//två variabler som behövs för att initialisera rutorna i rätt block
		int blockKolumn;
		int blockRad;
		
		//lägger till rutorna
		for(int rad=0;rad<9;rad++){
			for(int kol=0;kol<9;kol++){
				//räknar ut i vilket block den aktualla rutan ska befinna sig i
				blockKolumn= (kol-kol%3)/3;
				blockRad=(rad-rad%3)/3;
				//initaliserar rutan och lägger till den i rätt block
				squares[rad][kol]= new squares(rad,kol);
				boxes[blockRad][blockKolumn].add(squares[rad][kol]);
				//lägger till KeyListener, om den skrivna texten har längen 0 (dvs. t.ex. backspace har tryckts), så sätts texten till 0, sedan körs c.input, om false returnas så sätts rutans border och textfärg till rött, och ett ljud spelas upp
				squares[rad][kol].addKeyListener(new KeyAdapter() {
					public void keyReleased(KeyEvent e) {
						squares textField = (squares) e.getSource();
						String text = textField.getText();
						int rad = textField.getRad();
						int kol = textField.getKolumn();
						textField.setBorder(DefaultBorder);
						if(text.length()==0){
							text="0";
						}
						if((!(c.input(rad, kol, text.charAt(0))))){
							textField.setForeground(Color.RED);
							textField.setBorder(new LineBorder(Color.red,1));	
						    Toolkit.getDefaultToolkit().beep();     
						}
					}

				});
				//sätter alignment till center, gör rutan synlig, sätter text till blank, sätter enabled till true, sätter disabledtextcolor till black, sätter bakgrund till vitt
				squares[rad][kol].setHorizontalAlignment(SwingConstants.CENTER);
				squares[rad][kol].setVisible(true);
				squares[rad][kol].setText("");
				squares[rad][kol].setEnabled(true);
				squares[rad][kol].setDisabledTextColor(Color.black);
				squares[rad][kol].setBackground(Color.white);
				//om det finns ett nummer i den aktuella rutan så sätts det in i modellen och rutan blir grå och disabled
				if(model.getBoard(rad,kol)!=0){
					squares[rad][kol].setText(Integer.toString(model.getBoard(rad,kol)));
					squares[rad][kol].setEnabled(false);
					squares[rad][kol].setBackground(disabledBackgroundColour);
				}
			}
		}
		//lägger till brädan
		add(board);
		//gör brädan synlig
		setVisible(true);
	}
}

