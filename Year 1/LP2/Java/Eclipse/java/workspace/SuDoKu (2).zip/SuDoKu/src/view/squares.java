package view;
import javax.swing.*;

public class squares extends JTextField{
	public int rad;
	public int kolumn;
	public squares(int r, int k){
		rad = r;
		kolumn = k;
	}
	
	public int getRad(){
		return rad;
	}
	
	public int getKolumn(){
		return kolumn;
	}
}
