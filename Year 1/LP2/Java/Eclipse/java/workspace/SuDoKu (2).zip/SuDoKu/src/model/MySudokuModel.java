package model;
import java.beans.*;
import java.util.*;

public class MySudokuModel implements SudokuModel{
		
	private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);
	
	public void addPropertyChangeListener(PropertyChangeListener l){
		pcs.addPropertyChangeListener(l);
	}
		
	public void removePropertyChangeListener(PropertyChangeListener l){
		pcs.removePropertyChangeListener(l);
	}
	
	//array med värden för rutorna
	private int[][] m = new int[9][9];
	
	//konstruktor som sätter alla rutor till 0
	public MySudokuModel(){
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=0;
			}
		}	
	}
	
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	
	public MySudokuModel(MySudokuModel f){
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=f.getBoard(r,k);
			}
		}	
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	//Gör samma sak som getBoard
	@Override
	public String toString(){
		return getBoard();
	}
	
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void clear(){
		String oldValue = this.toString();
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				m[r][k]=0;
			}
		}	
		String newValue = this.toString();
		pcs.firePropertyChange("Modell", oldValue, newValue);
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void setBoard(int rad, int kolumn, int value){
		int oldValue = m[rad][kolumn];
		isLegal(value, rad, kolumn);
		m[rad][kolumn]=value;
		int newValue=m[rad][kolumn];
		pcs.fireIndexedPropertyChange("Value", 9*rad+kolumn, oldValue, newValue);
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	//Metod som kollar om man får sätta in värdet value i den angivna raden och kolumnen
	public boolean isLegal(int value, int rad, int kolumn) throws IllegalArgumentException{
		for(int i=0;i<9;i++){
			//kör igenom alla värden för den angivna raden och kollar om något är samma som värdet value, om det inte är på samma plats så returneras false
			if(m[rad][i]==value && i!=kolumn && m[rad][i]!=0){
				throw new IllegalArgumentException("Värdet " + value + " finns redan i rad " + rad + "! (Försöker att sätta in i kolumn " + kolumn + ", värdet finns redan i kolumn " + i + ")");
			}
			//kör igenom alla värden för den angivna kolumnen och kollar om något är samma som värdet value, om det inte är på samma plats så returneras false
			if(m[i][kolumn]==value && i!=rad && m[i][kolumn]!=0){
				throw new IllegalArgumentException("Värdet " + value + " finns redan i kolumn " + kolumn + "! (Försöker att sätta in i rad " + rad + ", värdet finns redan i rad "+ i + ")");
			}
		}
		//blocken numreras på följande sätt:
		//(0,0) (0,1) (0,2)
		//(1,0) (1,1) (1,2)
		//(2,0) (2,1) (2,2)
		//rad2 är den första "koordinaten", kol2 är den andra "koordinaten"
		//rad2 är alltså antalet gånger som tre går in i rad
		//kol2 är antalet gånger som tre går in i kolumn
		int rad2=((rad)-(rad)%3)/3;
		int kol2=(kolumn-kolumn%3)/3;
		//värdena som behöver kollas är alltså de vars rad är från rad2*3 till rad2*3 +3 och de vars kolumn är från kolumn2*3 till kolumn2*3 + 3
		for(int r=(0+rad2*3);r<(3+rad2*3);r++){
			for(int k = (0+kol2*3); k<(3+kol2*3); k++){
				if(m[r][k]==value && r!=rad && k!=kolumn && m[r][k]!=0){
					throw new IllegalArgumentException("Värdet " + value + " finns redan i block med radnummer " + rad2 + " och kolnummer " + kol2 + "! (Försöker att sätta in i rad " + r + " och kolumn " + k + ")");
				}
			}
		}
		return true;
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	public void setBoard(String s) throws IllegalArgumentException{
		String oldValue= this.toString();
		int rn;
		int kn;
		if(s==null || s.isEmpty()){
			throw new IllegalArgumentException("Stringen är tom!");
		}
		String rader[] = s.split("\\n");
		
		if(rader.length!=9){
			throw new IllegalArgumentException("Fel format!");
		}
		
		for(int i=0;i<9;i++){
			if(rader[i].length()!=9){
				throw new IllegalArgumentException("Fel format!");
			}
		}
		
		for (int r=0; r<9; r++){
			for(int k=0; k<9; k++){
				char character = rader[r].charAt(k);
				String tecken = Character.toString(character);
				if(tecken.matches("[0-9]+")){
					int value=Integer.parseInt(tecken);
					isLegal(value, r,k);
					rn=r+1;
					kn=k+1;
					m[r][k]=value;
				}
				else{
					m[r][k]=0;
				}
			}	
		}
		String newValue=this.toString();
		pcs.firePropertyChange("Modell", oldValue, newValue);
		
	}
	
	
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//returnar värdet i den angivna raden och kolumnen
	public int getBoard(int rad, int kolumn){
		return m[rad][kolumn];
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	//ger en string som beskriver spelplanet genom att för varje rad i sudokut lägga till alla värdena i raden i sudokut och sedan byta till nästa rad i stringen
	public String getBoard(){
		String HelaSpelet = "";
		for(int i=0; i<9; i++){
			for(int p=0; p<9; p++){
				HelaSpelet=HelaSpelet + Integer.toString(m[i][p]);
				}
			HelaSpelet = HelaSpelet + "\n";
			}
		return HelaSpelet;
	}
	

	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	

	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	List <String> lista = new ArrayList<>();
	//löser sudokut
	
	public boolean solve(){
		//listan behövs för att kunna ange sudokuts begynnelsevärde i pcs.firePropertyChange
		lista.add(this.toString());
		//om AntalNollor=0 return true
		int AntalNollor = 0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					AntalNollor++;
				}
			}
		}
		if(AntalNollor==0){
			pcs.firePropertyChange("Modell",lista.get(0), this.toString());
			lista.clear();
			return true;
		}
		//hittar vilken cell som har minst antal nollor i block kolumn o rad
		int blockNollor[][]= new int[3][3];
		for(int blockRad=0;blockRad<3;blockRad++){
			for(int blockKolumn=0;blockKolumn<3;blockKolumn++){
				for(int rad=blockRad*3; rad<blockRad*3+3; rad++){
					for(int kol=blockKolumn*3; kol<blockKolumn*3+3;kol++){
						if(m[rad][kol]==0){
							blockNollor[blockRad][blockKolumn]++;
						}
					}
				}
			}
		}
		int nollorIRad[]= new int[9];
		int nollorIKol[] = new int[9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					nollorIRad[r]++;
					nollorIKol[k]++;
				}
			}
		}
		int blockKolumn=0;
		int blockRad=0;
		int nollor[][] = new int[9][9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					blockKolumn= (k-k%3)/3;
					blockRad=(r-r%3)/3;
					nollor[r][k]=nollorIRad[r]+nollorIKol[k]+blockNollor[blockRad][blockKolumn];
				
				}
			}
		}
		int kolNolMin=0;
		int radNolMin=0;
		loop:
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
					break loop;
				}
			}
		}
		//System.out.println("RAD" + radNolMin +" KOL " + kolNolMin);

		for(int r=0;r<9;r++){
			for(int k=0; k<9;k++){
				if(nollor[r][k]<nollor[radNolMin][kolNolMin]&&m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
				}
			}
		}
		//System.out.println("RAD" + radNolMin +" KOL " + kolNolMin);
		//System.out.println(this.getBoard());

		//löser sudokut genom rekursion
		for(int number=1;number<=9;number++){
			try{
				isLegal(number, radNolMin, kolNolMin);
			}		
			catch (Exception e){
				continue;
			}
			m[radNolMin][kolNolMin] = number;
			if(solve()){
				return true;
			}
			else{
				m[radNolMin][kolNolMin] = 0;
			}
		}

		lista.clear();
		return false;
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	int i = 0;
	//metoden solve med en integer som parameter behövs till isUnique. När den har hittat en lösning så sätter den i till 1 och letar vidare, om den då hittar en till så returnas true
	public boolean uniqueSolve(){
		//listan behövs för att kunna ange sudokuts begynnelsevärde i pcs.firePropertyChange
		//om AntalNollor=0 return true
		int AntalNollor = 0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					AntalNollor++;
				}
			}
		}
		if(AntalNollor==0 && i!=0){
			return true;
		}
		
		if(AntalNollor==0 && i==0){
			i++;
		}
		
		//hittar vilken cell som har minst antal nollor i block kolumn o rad
		int blockNollor[][]= new int[3][3];
		for(int blockRad=0;blockRad<3;blockRad++){
			for(int blockKolumn=0;blockKolumn<3;blockKolumn++){
				for(int rad=blockRad*3; rad<blockRad*3+3; rad++){
					for(int kol=blockKolumn*3; kol<blockKolumn*3+3;kol++){
						if(m[rad][kol]==0){
							blockNollor[blockRad][blockKolumn]++;
						}
					}
				}
			}
		}
		int nollorIRad[]= new int[9];
		int nollorIKol[] = new int[9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					nollorIRad[r]++;
					nollorIKol[k]++;
				}
			}
		}
		int blockKolumn=0;
		int blockRad=0;
		int nollor[][] = new int[9][9];
		for(int r=0; r<9;r++){
			for(int k=0; k<9;k++){
				if(m[r][k]==0){
					blockKolumn= (k-k%3)/3;
					blockRad=(r-r%3)/3;
					nollor[r][k]=nollorIRad[r]+nollorIKol[k]+blockNollor[blockRad][blockKolumn];
				
				}
			}
		}
		int kolNolMin=0;
		int radNolMin=0;
		for(int r=0; r<9;r++){
			for(int k=0;k<9;k++){
				if(m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
					break;
				}
			}
		}
		
		for(int r=0;r<9;r++){
			for(int k=0; k<9;k++){
				if(nollor[r][k]<nollor[radNolMin][kolNolMin]&&m[r][k]==0){
					radNolMin=r;
					kolNolMin=k;
				}
			}
		}
		

		if(radNolMin==0 && kolNolMin==0){
			if(nollor[0][0]==0){
					return false;
			}
		}
		//löser sudokut genom rekursion
		for(int number=1;number<=9;number++){
			try{
				isLegal(number, radNolMin, kolNolMin);
			}		
			catch (Exception e){
				continue;
			}
				m[radNolMin][kolNolMin] = number;
				if(uniqueSolve()){
					return true;
				}
				else{
					m[radNolMin][kolNolMin] = 0;
				}
			}
		
		return false;
	}
	
	


	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	//kollar om Sudokut går att lösa genom att köra solve på en kopia
	public boolean isSolvable(){
		MySudokuModel kopia = new MySudokuModel(this);
		return kopia.solve();
	}
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	
	//Kollar om sudokut går att solva, om det gör det så kollar den om den har mer än en lösning, om den har mer än en lösning så return false, om den har en lösning så return true, om den saknar lösning så return false
	public boolean isUnique(){
		MySudokuModel kopia = new MySudokuModel(this);
		MySudokuModel kopia2 = new MySudokuModel(this);
		if(kopia2.solve()){
			if(kopia.uniqueSolve()){
				return false;
			}
			else{
				return true;
			}
		}
		else{
			return false;
		}
	}
	
	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	public static void main(String[] args){
		MySudokuModel k = new MySudokuModel();
		k.clear();
		//k.setBoard("..3.2.6..\n9..3.5..1\n..18.64..\n..81.29..\n7.....7.8\n..67.82..\n..26.95..\n8..2.3..9\n..5.1.3..");
		//System.out.println(k.getBoard());
		
		MySudokuModel f = new MySudokuModel();
		f.setBoard("000000000\n000000000\n000000000\n000000000\n000000000\n000000000\n000000000\n000000000\n000000000");
		System.out.println(f.toString());
		





	}
}
