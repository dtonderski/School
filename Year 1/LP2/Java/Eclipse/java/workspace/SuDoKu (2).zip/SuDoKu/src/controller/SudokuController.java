package controller;
 public interface SudokuController {
   boolean input(int row, int col, char value);		
 }
